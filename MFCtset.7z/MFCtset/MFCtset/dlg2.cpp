﻿// dlg2.cpp: 实现文件
//

#include "pch.h"
#include "MFCtset.h"
#include "afxdialogex.h"
#include "dlg2.h"


// dlg2 对话框

IMPLEMENT_DYNAMIC(dlg2, CDialogEx)

dlg2::dlg2(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG2, pParent)
{

}

dlg2::~dlg2()
{
}

void dlg2::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(dlg2, CDialogEx)
END_MESSAGE_MAP()


// dlg2 消息处理程序
