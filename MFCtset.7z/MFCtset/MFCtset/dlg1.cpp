﻿// dlg1.cpp: 实现文件
//

#include "pch.h"
#include "MFCtset.h"
#include "afxdialogex.h"
#include "dlg1.h"


// dlg1 对话框

IMPLEMENT_DYNAMIC(dlg1, CDialogEx)

dlg1::dlg1(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG2, pParent)
{

}

dlg1::~dlg1()
{
}

void dlg1::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(dlg1, CDialogEx)
END_MESSAGE_MAP()


// dlg1 消息处理程序
